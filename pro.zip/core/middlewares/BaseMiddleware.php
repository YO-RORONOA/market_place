<?php

namespace App\core\middlewares;

use App\core\Application;

abstract class BaseMiddleware
{
    abstract public function execute();
}







