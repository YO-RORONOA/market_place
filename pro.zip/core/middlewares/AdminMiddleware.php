<?php

namespace App\core\middlewares;

use App\core\Application;
use App\core\exception\ForbiddenException;
use App\models\Role;

class AdminMiddleware extends BaseMiddleware
{
    public array $actions = [];
    
    public function __construct(array $actions = [])
    {
        $this->actions = $actions;
    }
    
    public function execute()
    {
      
        if (empty($this->actions) || in_array(Application::$app->controller->action, $this->actions)) {
            $user = Application::$app->session->get('user');
            
            if (!$user) {
                Application::$app->session->setFlash('error', 'You must be logged in to access this page');
                Application::$app->response->redirect('/admin/login');
                exit;
            }
            
            $roles = $user['roles'] ?? [];
            
            if (!in_array(Role::ADMIN, $roles)) {
                throw new ForbiddenException('You do not have administrator privileges to access this page');
            }
            
            // Ensure admin is the active role
            $activeRole = $user['active_role'] ?? null;
            if ($activeRole !== Role::ADMIN) {
                $user['active_role'] = Role::ADMIN;
                Application::$app->session->set('user', $user);
            }
        }
    }
}