<?php

namespace App\migrations;


abstract class Migration
{
    abstract public function up();
    abstract public function down();

}