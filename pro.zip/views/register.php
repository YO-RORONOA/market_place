<h1>Register</h1>





<?php
use App\core\form\Form;
 $form = Form::begin('', "post") ?>
 
    <?php echo $form->field($model,"firstname") ?>
    <?php echo $form->field($model,"lastname") ?>
    <?php echo $form->field($model,"email") ?>
    <?php echo $form->field($model,"password")->passwordField() ?>
    <?php echo $form->field($model,"passwordConfirm")->passwordField() ?>


    <button type="submit" class="btn btn-primary">Submit</button>
<?php Form::end() ?>






<!-- 
<form action="" method="POST">
    <div class="form-group">
    <div class="form-group">
        <label for="exampleInputPassword1">firstname</label>
        <input name="firstName" type="text" class="form-control">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">lastname</label>
        <input name="lastName" type="text" class="form-control">
    </div>
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input name="password" type="password" class="form-control">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input name="passwordConfirm" type="password" class="form-control">
    </div>
    <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Check me out</label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form> -->